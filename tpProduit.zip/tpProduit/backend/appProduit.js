const express = require('express');
const mongoose = require('mongoose');
const app = express();
app.use(express.json());

const body_parser=require('body-parser');
app.use(body_parser.json());
const cors=require('cors');
app.use(cors());
const Produit = require('./models/ProductShema');

mongoose.connect('mongodb+srv://loubna:loubna25@cluster0.eu2184m.mongodb.net/?retryWrites=true&w=majority',
  { useNewUrlParser: true,
    useUnifiedTopology: true })
  .then(() => console.log('Connexion à MongoDB réussie !'))
  .catch(() => console.log('Connexion à MongoDB échouée !'));

app.post('/api/products', (req, res, next) => {
  const prd = new Produit({// dans la base de donnée
    ...req.body //enregistrer tous les données
    //...req.body.name pour enregistrer seul le name
  });
  prd.save()
    .then((prd) => res.status(201).json({ product:prd}))//si il est enregistrer
    .catch(error => res.status(500).json({ error }));//else
});

//afficher les produits qui sons dand la base de donnée
app.get('/api/products', (req, res, next) => {
  Produit.find()
  .then(prds => res.status(200).json({products:prds}))
  .catch(error => res.status(400).json({ error }));
});

app.get('/api/products/:id', (req, res, next) => {
  Produit.findOne({ _id: req.params.id })
    .then(p => res.status(200).json({product: p }))
    .catch(error => res.status(404).json({ error }));
});

//pour modifier
app.put('/api/products/:id', (req, res, next) => {
  Produit.updateOne({ _id: req.params.id }, { 
    ...req.body
    , _id: req.params.id })
    .then(() => res.status(200).json({ message: 'Modified !'}))
    .catch(error => res.status(400).json({ error }));
});

app.delete('/api/products/:id', (req, res, next) => {
  Produit.deleteOne({ _id: req.params.id })
    .then(() => res.status(200).json({ message: 'Deleted'}))
    .catch(error => res.status(400).json({ error }));
});
  
  /*app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content, Accept, Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    next();
  });*/



  


  

module.exports = app;