const express = require("express");
const app = express();
const PORT = process.env.PORT_ONE || 4000;
const mongoose = require("mongoose");
const Produit = require("./Produit");
app.use(express.json());
const auth = require('./isAuthenticated');

mongoose.set('strictQuery', true);
mongoose.connect('mongodb://127.0.0.1:27017/publication-service-DB',
{ useNewUrlParser: true,
  useUnifiedTopology: true })
.then(() => console.log('Connexion à MongoDB réussie !'))
.catch(() => console.log('Connexion à MongoDB échouée !'));


app.post("/produit/ajouter",auth, (req, res, next) => {
    
    const prd = new Produit({
        ...req.body 
       
      });
      prd.save()
        .then((prd) => res.status(201).json(prd))
        .catch(error => res.status(500).json({ error }));
});
app.post("/produit/acheter", (req, res, next) => {

    console.log(req.body);

    Produit.find({_id: {$in:req.body.ids}})
    .then(prds => res.status(200).json(prds))
    .catch(error => res.status(400).json({ error }));
});


  
 
app.listen(PORT, () => {
    console.log(`Product-Service at ${PORT}`);
    });
    