const express = require("express");
const app = express();
const PORT = process.env.PORT_ONE || 
4001;
const mongoose = require("mongoose");
const Commande = require("./Commande");
const axios = require('axios');

const auth = require('./isAuthenticated');
//Connexion à la base de données
mongoose.set('strictQuery', true);
mongoose.connect('mongodb://127.0.0.1:27017/publication-service-DB',
{ useNewUrlParser: true,
  useUnifiedTopology: true })
.then(() => console.log('Connexion à MongoDB réussie !'))
.catch(() => console.log('Connexion à MongoDB échouée !'));

app.use(express.json());



function prixTotal(produits) {
    let sum = 0;
    for (let i = 0; i < produits.length; i++) {
        sum += produits[i].prix;
    }
    return sum;

}

async function httpRequest(ids) {
    try {
        const URL = "http://localhost:4000/produit/acheter"
        const response = await axios.post(URL, { ids: ids }, {
        headers: {
        'Content-Type': 'application/json'
    }
    });
    console.log('ok');
    return prixTotal(response.data);
    } catch (error) {
    console.error(error);
    }
}

app.post("/commande/ajouter",auth, async (req, res, next) => {
    console.log(req.body.ids);
    httpRequest(req.body.ids)

    .then((total)=>
   {console.log(total);
    const cmd = new Commande({
        produits:req.body.ids,
        email_utilisateur:req.auth.email,
        prix_total:total
       
      });
      cmd.save()
        .then((cmd) => res.status(201).json(cmd))
        .catch(error => res.status(500).json({ error }))})
        .catch(error => res.status(500).json({ error }));
        
});

app.listen(PORT, () => {
console.log(`Commande-Service at ${PORT}`);
});