const jwt = require('jsonwebtoken');
module.exports = async function
isAuthenticated(req, res, next) {
    try {
        const token = req.headers.authorization.split(' ')[1];
        const decodedToken = jwt.verify(token, 'RANDOM_TOKEN_SECRET');
        console.log('ok');
        const email = decodedToken.email;
        req.auth = {
            email: email
        };
     next();
    } catch(error) {
        res.status(401).json({ error });
    }
};
