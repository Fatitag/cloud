const express = require("express");
const app = express();
const PORT = process.env.PORT_ONE || 4002;
const mongoose = require("mongoose");
const Utilisateur = require("./utilisateur");
const jwt = require("jsonwebtoken");
const bcrypt = require('bcryptjs');
mongoose.set('strictQuery', true);
mongoose.connect('mongodb://127.0.0.1:27017/publication-service-DB',
{ useNewUrlParser: true,
  useUnifiedTopology: true })
.then(() => console.log('Connexion à MongoDB réussie !'))
.catch(() => console.log('Connexion à MongoDB échouée !'));

app.use(express.json());

app.post("/auth/register", async (req, res) => {
   
        bcrypt.hash(req.body.password, 10)
          .then(hash => {
            const user = new Utilisateur({
              nom:req.body.nom,
              email: req.body.email,
           
            password: hash
              
            });
           
            user.save()
              .then(() => res.status(201).json({ message: 'Utilisateur créé !' }))
              .catch(error => res.status(400).json({ error }));
          })
          .catch(error => res.status(500).json({ error }));
      }
    );

app.post("/auth/login", async (req, res) => {
    Utilisateur.findOne({ email: req.body.email })
    .then(user => {
        if (!user) {
            return res.status(401).json({ message: 'Paire login/mot de passe incorrecte'});
        }
        bcrypt.compare(req.body.password, user.password)
            .then(valid => {
                if (!valid) {
                    return res.status(401).json({ message: 'Paire login/mot de passe incorrecte' });
                }
                res.status(200).json({
                   
                    token: jwt.sign(
                        { email: user.email },
                        'RANDOM_TOKEN_SECRET',
                        { expiresIn: '24h' }
                    )
                });
            })
            .catch(error => res.status(500).json({ error }));
    })
    .catch(error => res.status(500).json({ error }));
})



app.listen(PORT, () => {
        console.log(`Auth-Service at ${PORT}`);
        });